# Sai Krishna — Interactive CRM Portfolio

A static portfolio with a rotatable 3D CRM universe, working module simulations, Power Pages portal, integration and debugging demos, and a contact experience.

## Publish with GitHub Pages

1. Extract the ZIP on your computer.
2. Create a GitHub repository, or open the repository for your existing portfolio.
3. Choose **Add file → Upload files**. Upload the extracted files, not the ZIP. Put `index.html` and the other site files directly in the repository root. Commit to `main`.
4. Open **Settings → Pages**.
5. Select **Deploy from a branch**, then **main** and **/(root)**. Save.
6. Wait for the Pages deployment to finish. GitHub displays your published URL in Pages settings.

For an existing site, replace its homepage only if that is what you intend. Otherwise upload this entire package to a subfolder such as `crm-experience` and link to that folder from your existing homepage. Keep these files together.

Official guidance: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Files

| File | Purpose |
| --- | --- |
| index.html | Entry point and shared markup |
| styles.css | All responsive styles and 3D geometry |
| script.js | CRM modules, records, validation and navigation |
| universe.js | 3D navigation, camera and deep links |
| portal.js | Power Pages demo and integration simulator |
| contact.js | Contact page and email inquiry builder |
| sai-krishna-vala.vcf | Downloadable contact card |
| .nojekyll | Serve as a plain static website |

No npm packages, build step, server, API key or database are required. Keep the script order in index.html unchanged. The 3D view uses CSS perspective and transforms.

## Run locally

Open the folder in VS Code and use Live Server, or run `python -m http.server 8000` from the folder and visit http://localhost:8000.

## Contact and direct links

The contact email is vsaik0801@gmail.com. Email links open the visitor’s configured email application; they do not send messages automatically. Update contact.js and the VCF if your details change.

Use `#contact`, `#portal`, `#sales`, `#service`, `#field`, `#journeys`, `#project`, `#ai`, `#architecture`, `#govern` or `#debug` after your site URL to open that experience directly.

## Demo boundaries

All records and integrations are fictional browser simulations. State resets when the page reloads. There is no live Dataverse, Microsoft Graph, Power Pages authentication, AI model or server-side authorization. The contact form prepares an email draft and does not store submitted information. GitHub publication does not inherit the private access of the review site.

JavaScript syntax and local asset references were checked. Visual browser verification was unavailable in the authoring environment.
